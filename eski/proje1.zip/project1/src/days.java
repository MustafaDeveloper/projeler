import java.util.Scanner;

public class days {

        /*
               Aşağıda verilen gün adlarına göre, Girilen bir gün numarasına karşılk gelen gün adını yazınız.

                Eger int 1 ise print monday
                Eger int 2 ise print tuesday
                Eger int 3 ise print wednesday
                Eger int 4 ise print thursday
                Eger int 5 ise print friday
                Eger int 6 ise print saturday
                Eger int 7 ise print sunday
                Eger int 8 den buyuk ise  print "this is not a valid day"

                NOT : BU PROBLEMI ÇÖZERKEN SWITCH STATEMENT KULLANIN
         */

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int day = scanner.nextInt();

        //  kodu burdan başlatın ve bu satırdan önceki kodlari degiştirmeyin


    }
}



